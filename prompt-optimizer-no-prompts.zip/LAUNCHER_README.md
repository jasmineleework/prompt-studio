# Prompt Optimizer - Mac 一键启动器

## 🚀 快速开始

### 最简单的使用方法
1. **双击 `start.command`** - 应用会自动启动并打开浏览器
2. 开始使用！

就是这么简单！🎉

## 📋 系统要求

- **macOS**: 10.15 (Catalina) 或更高版本
- **Node.js**: 16.0 或更高版本（如未安装，运行 `setup.command` 会引导您安装）
- **浏览器**: 任何现代浏览器（Chrome、Safari、Firefox、Edge）

## 📦 文件说明

```
prompt-optimizer-mac/
├── start.command      # 一键启动脚本（主要使用这个）
├── setup.command      # 首次安装/环境检查脚本
├── .env.local.example # 配置文件模板（AI 功能需要）
├── prompts/          # 您的 Prompt 文件存储位置
└── ...               # 其他应用文件
```

## 🛠 首次使用指南

### 选项 1：直接启动（推荐）
- 直接双击 `start.command`
- 脚本会自动检查环境并安装必要的依赖

### 选项 2：使用安装向导
- 双击 `setup.command` 运行安装向导
- 向导会：
  - 检查 Node.js 是否安装
  - 安装项目依赖
  - 创建配置文件
  - 可选：创建桌面快捷方式

## ⚙️ 配置 AI 功能（可选）

如果您想使用 AI 分析和优化功能：

1. 复制配置文件模板：
   ```bash
   cp .env.local.example .env.local
   ```

2. 编辑 `.env.local` 文件，添加您的 OpenAI API Key：
   ```
   OPENAI_API_KEY=sk-your-api-key-here
   ```

3. 重新启动应用

## 🎯 核心功能

- **项目管理**: 创建和管理多个 Prompt 项目
- **文件夹组织**: 使用文件夹分类管理项目
- **版本控制**: 自动保存每次编辑的版本
- **AI 分析**: 检查 Prompt 与系统规则的冲突（需要 API Key）
- **本地存储**: 所有数据存储在本地，保护您的隐私

## 🔧 常见问题

### Q: 双击 start.command 没有反应？
**A**: 可能是权限问题，在终端运行：
```bash
chmod +x start.command
./start.command
```

### Q: 提示"未找到 Node.js"？
**A**: 您需要先安装 Node.js：
1. 运行 `setup.command`，它会引导您安装
2. 或访问 https://nodejs.org/ 手动下载安装

### Q: 端口 3000 已被占用？
**A**: 启动脚本会自动检测并使用下一个可用端口（3001, 3002...）

### Q: 如何停止服务器？
**A**: 在终端窗口按 `Ctrl + C` 或直接关闭终端窗口

### Q: 数据存储在哪里？
**A**: 所有项目数据存储在浏览器的 IndexedDB 中，不会上传到任何服务器

## 📦 构建您自己的启动器

如果您想从源代码构建启动器：

```bash
# 安装依赖
npm install

# 构建 Mac 启动器
npm run package:mac

# 输出文件在 dist/prompt-optimizer-mac.tar.gz
```

## 🔄 更新

要更新到新版本：
1. 下载新版本的启动器
2. 解压到新目录
3. 复制旧版本的 `.env.local` 文件（如果有）
4. 运行新版本

注意：您的项目数据存储在浏览器中，更新应用不会影响数据。

## 💡 提示和技巧

1. **快捷键**: 在应用中使用 `Cmd + S` 保存版本
2. **拖拽**: 可以拖拽项目到文件夹中进行组织
3. **导出**: 使用导出功能备份所有项目数据
4. **折叠面板**: 点击右侧 AI 面板可以折叠，节省空间

## 🐛 反馈和支持

如果您遇到问题或有改进建议，欢迎：
- 提交 Issue 到项目仓库
- 发送反馈邮件
- 参与项目贡献

## 📄 许可证

MIT License - 自由使用和修改

---

**享受使用 Prompt Optimizer！** 🎊

如有任何问题，请随时查阅此文档或联系支持。