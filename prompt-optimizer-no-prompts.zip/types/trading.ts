// 交易系统配置相关类型

export interface TradingConfig {
  systemConstraints: string      // 系统限制文本
  outputFormat: string           // 输出格式文本
  enabled: boolean              // 是否启用这些限制
  aiConfig?: AIConfig           // AI配置（可选）
}

export interface AIConfig {
  enabled: boolean              // 是否启用AI检测
  provider: 'openai' | 'deepseek'  // AI服务商
  apiKey: string               // API密钥
  baseURL?: string            // API基础URL（用于DeepSeek等）
  model: string               // 模型名称
  temperature?: number        // 生成温度
  maxTokens?: number         // 最大token数
}

export interface ConflictAnalysis {
  timestamp: Date
  conflicts: Conflict[]
  suggestions: Suggestion[]
  score: {
    compatibility: number      // 兼容性评分 0-100
    severity: 'low' | 'medium' | 'high'
  }
}

export interface Conflict {
  id: string
  type: 'position' | 'leverage' | 'risk' | 'output' | 'logic'
  severity: 'error' | 'warning' | 'info'
  userText: string            // 用户Prompt中的冲突文本
  systemRule: string          // 系统规则
  explanation: string         // 冲突说明
  lineNumber?: number         // 在Prompt中的位置
}

export interface Suggestion {
  id: string
  type: 'fix' | 'improvement' | 'optimization'
  title: string
  description: string
  oldText?: string
  newText?: string
  impact: 'low' | 'medium' | 'high'
}

export interface AnalysisRequest {
  prompt: string
  config: TradingConfig
  useAI?: boolean
}

export interface AnalysisResponse {
  success: boolean
  analysis?: ConflictAnalysis
  error?: string
}