import { AIConfig, ConflictAnalysis } from '@/types/trading'

export interface AIClient {
  analyzeConflicts(
    prompt: string, 
    systemConstraints: string, 
    outputFormat: string
  ): Promise<ConflictAnalysis>
}

export class OpenAIClient implements AIClient {
  constructor(private config: AIConfig) {}

  async analyzeConflicts(
    prompt: string, 
    systemConstraints: string, 
    outputFormat: string
  ): Promise<ConflictAnalysis> {
    const OpenAI = (await import('openai')).default
    
    const openai = new OpenAI({
      apiKey: this.config.apiKey,
      baseURL: this.config.baseURL
    })

    const analysisPrompt = this.buildAnalysisPrompt(prompt, systemConstraints, outputFormat)

    try {
      const completion = await openai.chat.completions.create({
        model: this.config.model,
        messages: [
          {
            role: 'system',
            content: 'You are a professional trading system conflict detector. Analyze the user prompt against trading system constraints and return results in the exact JSON format specified.'
          },
          {
            role: 'user', 
            content: analysisPrompt
          }
        ],
        temperature: this.config.temperature || 0.1,
        max_tokens: this.config.maxTokens || 8000,
        response_format: { type: 'json_object' }
      })

      const content = completion.choices[0]?.message?.content
      if (!content) {
        throw new Error('AI返回内容为空')
      }

      const result = JSON.parse(content)
      return this.formatAnalysisResult(result)
    } catch (error) {
      console.error('AI分析失败:', error)
      throw new Error('AI分析服务异常')
    }
  }

  private addLineNumbers(text: string): string {
    return text.split('\n')
      .map((line, index) => `${index + 1}: ${line}`)
      .join('\n')
  }

  private buildAnalysisPrompt(prompt: string, systemConstraints: string, outputFormat: string): string {
    const numberedPrompt = this.addLineNumbers(prompt)
    
    return `请分析以下用户交易Prompt与系统约束的冲突：

**用户Prompt（带行号）:**
\`\`\`
${numberedPrompt}
\`\`\`

**系统约束:**
\`\`\`
${systemConstraints}
\`\`\`

**要求输出格式:**
\`\`\`
${outputFormat}
\`\`\`

请严格按照以下JSON格式返回分析结果：

\`\`\`json
{
  "conflicts": [
    {
      "id": "conflict-1",
      "type": "position",
      "severity": "error",
      "userText": "逐步加仓",
      "systemRule": "禁止加仓",
      "explanation": "用户提到逐步加仓，但系统禁止任何形式的加仓操作",
      "lineNumber": 3
    },
    {
      "id": "conflict-2", 
      "type": "leverage",
      "severity": "error",
      "userText": "50倍杠杆",
      "systemRule": "最大杠杆20倍",
      "explanation": "用户要求50倍杠杆，超过系统最大限制20倍",
      "lineNumber": 5
    },
    {
      "id": "conflict-3",
      "type": "position", 
      "severity": "error",
      "userText": "部分平仓",
      "systemRule": "禁止部分平仓",
      "explanation": "用户提到部分平仓，但系统只允许完全平仓",
      "lineNumber": 7
    }
    // 如果发现更多冲突，继续添加到数组中，不要限制数量
  ],
  "suggestions": [
    {
      "id": "唯一标识符",
      "type": "fix|improvement|optimization", 
      "title": "修复建议标题",
      "description": "详细修复说明",
      "oldText": "需要修改的原始文本",
      "newText": "修改后的建议文本",
      "impact": "low|medium|high"
    }
  ],
  "score": {
    "compatibility": "0-100的兼容性评分",
    "severity": "low|medium|high"
  }
}
\`\`\`

要求：
1. **重要**: 检测并返回用户Prompt中的【所有】冲突，不要遗漏任何问题
   - 不要限制冲突数量，如果发现10个问题就返回10个
   - 确保覆盖所有类型的冲突：仓位管理、风险控制、杠杆限制、输出格式等
2. 仔细分析显性与隐性的语义冲突，不仅仅是关键词匹配
3. 分析是否存在任何用户交易Prompt中的表述，导致系统无法准确按照要求输出格式输出有效的交易信号
4. **行号定位要求**: 为每个冲突提供准确的行号定位
   - 行号格式：返回数字（如：3、12、15）
   - 行号定位：基于上面带行号的用户Prompt，找到冲突内容所在的具体行
   - 示例：如果冲突在"3: 逐步加仓"这行，则返回lineNumber: 3
5. 生成实用的修复建议
6. 评估整体风险等级

**分析策略**：
1. 逐行扫描用户Prompt，不要跳过任何行
2. 检查每行是否违反任何系统规则
3. 为每个发现的违规创建独立的冲突对象
4. 确保返回完整的冲突列表，不要因为数量多而省略

**行号定位示例**：
- 用户Prompt: "1: 创建交易策略\n2: 首先建立仓位\n3: 然后逐步加仓"  
- 冲突检测："逐步加仓"违反系统规则
- 返回：lineNumber: 3`
  }

  private validateLineNumber(lineNumber: any): number | undefined {
    // 验证行号是否为有效数字
    if (typeof lineNumber === 'number' && lineNumber > 0) {
      return lineNumber
    }
    if (typeof lineNumber === 'string') {
      const parsed = parseInt(lineNumber, 10)
      if (!isNaN(parsed) && parsed > 0) {
        return parsed
      }
    }
    return undefined
  }

  private formatAnalysisResult(result: any): ConflictAnalysis {
    const { v4: uuidv4 } = require('uuid')
    
    return {
      timestamp: new Date(),
      conflicts: (result.conflicts || []).map((conflict: any) => ({
        id: conflict.id || uuidv4(),
        type: conflict.type || 'logic',
        severity: conflict.severity || 'warning',
        userText: conflict.userText || '',
        systemRule: conflict.systemRule || '',
        explanation: conflict.explanation || '',
        lineNumber: this.validateLineNumber(conflict.lineNumber)
      })),
      suggestions: (result.suggestions || []).map((suggestion: any) => ({
        id: suggestion.id || uuidv4(),
        type: suggestion.type || 'improvement',
        title: suggestion.title || '',
        description: suggestion.description || '',
        oldText: suggestion.oldText,
        newText: suggestion.newText,
        impact: suggestion.impact || 'medium'
      })),
      score: {
        compatibility: result.score?.compatibility || 100,
        severity: result.score?.severity || 'low'
      }
    }
  }
}

export class DeepSeekClient implements AIClient {
  constructor(private config: AIConfig) {}

  async analyzeConflicts(
    prompt: string, 
    systemConstraints: string, 
    outputFormat: string
  ): Promise<ConflictAnalysis> {
    // DeepSeek API与OpenAI兼容，直接复用OpenAI客户端
    const openaiClient = new OpenAIClient({
      ...this.config,
      baseURL: this.config.baseURL || 'https://api.deepseek.com/v1'
    })
    
    return openaiClient.analyzeConflicts(prompt, systemConstraints, outputFormat)
  }
}

export function createAIClient(config: AIConfig): AIClient {
  switch (config.provider) {
    case 'openai':
      return new OpenAIClient(config)
    case 'deepseek':
      return new DeepSeekClient(config)
    default:
      throw new Error(`不支持的AI服务商: ${config.provider}`)
  }
}