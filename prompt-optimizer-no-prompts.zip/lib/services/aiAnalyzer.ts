import { ConflictAnalysis, AIConfig } from '@/types/trading'
import { createAIClient } from './aiClient'
import { conflictAnalyzer } from '@/lib/validators/conflictAnalyzer'

export class AIAnalyzer {
  /**
   * 使用AI分析Prompt冲突
   */
  async analyzeWithAI(
    prompt: string,
    systemConstraints: string,
    outputFormat: string,
    aiConfig: AIConfig
  ): Promise<ConflictAnalysis> {
    // 验证AI配置
    if (!aiConfig.enabled || !aiConfig.apiKey.trim()) {
      throw new Error('AI配置无效或未启用')
    }

    try {
      const aiClient = createAIClient(aiConfig)
      return await aiClient.analyzeConflicts(prompt, systemConstraints, outputFormat)
    } catch (error) {
      console.error('AI分析失败，回退到规则检测:', error)
      // 回退到原有的规则检测
      return conflictAnalyzer.analyzePrompt(prompt, systemConstraints, outputFormat)
    }
  }

  /**
   * 分析Prompt冲突（优先使用AI，回退到规则检测）
   */
  async analyzeConflicts(
    prompt: string,
    systemConstraints: string,
    outputFormat: string,
    aiConfig?: AIConfig
  ): Promise<ConflictAnalysis> {
    // 如果有AI配置且启用，优先使用AI检测
    if (aiConfig?.enabled && aiConfig.apiKey.trim()) {
      try {
        return await this.analyzeWithAI(prompt, systemConstraints, outputFormat, aiConfig)
      } catch (error) {
        console.warn('AI检测失败，使用规则检测:', error)
      }
    }

    // 回退到规则检测
    return conflictAnalyzer.analyzePrompt(prompt, systemConstraints, outputFormat)
  }
}

export const aiAnalyzer = new AIAnalyzer()