import { create } from 'zustand'
import { Project, Version, Folder, ProjectStructure } from '@/types'
import { getDB } from './database'
import { v4 as uuidv4 } from 'uuid'

interface LocalProject {
  name: string
  versions: {
    versionNumber: number
    content: string
    fileName: string
  }[]
}

interface LoadLocalResponse {
  success: boolean
  projects: LocalProject[]
  structure: ProjectStructure | null
  lastModified: string | null
}

interface ProjectState {
  projects: Project[]
  folders: Folder[]
  currentProject: Project | null
  isLoading: boolean
  loadProjects: () => Promise<void>
  createProject: (name: string, description?: string, folderId?: string) => Promise<Project>
  selectProject: (projectId: string) => void
  updateProject: (projectId: string, updates: Partial<Project>) => Promise<void>
  deleteProject: (projectId: string) => Promise<void>
  createFolder: (name: string, parentId?: string) => Promise<Folder>
  updateFolder: (folderId: string, updates: Partial<Folder>) => Promise<void>
  deleteFolder: (folderId: string, deleteProjects?: boolean) => Promise<void>
  toggleFolderCollapse: (folderId: string) => Promise<void>
  moveProjectToFolder: (projectId: string, folderId: string | null) => Promise<void>
  restoreFromLocal: () => Promise<void>
  syncStructureToLocal: () => Promise<void>
  needsRestoreFromLocal: () => Promise<boolean>
}

// 使用共享的数据库配置

export const useProjectStore = create<ProjectState>((set, get) => ({
  projects: [],
  folders: [],
  currentProject: null,
  isLoading: false,

  loadProjects: async () => {
    set({ isLoading: true })
    try {
      const db = await getDB()
      
      // 智能检测是否需要从本地文件恢复
      const needsRestore = await get().needsRestoreFromLocal()
      
      if (needsRestore) {
        console.log('Local files changed or no data found, restoring from local files...')
        await get().restoreFromLocal()
      } else {
        console.log('Using existing IndexedDB data')
      }
      
      // 获取数据
      let projects = await db.getAll('projects')
      let folders = []
      
      try {
        folders = await db.getAll('folders')
      } catch (error) {
        console.log('Folders store not available, using empty array')
        folders = []
      }
      
      set({ 
        projects,
        folders,
        currentProject: projects.length > 0 ? projects[0] : null,
        isLoading: false 
      })
    } catch (error) {
      console.error('Failed to load projects:', error)
      set({ isLoading: false })
    }
  },

  createProject: async (name: string, description?: string, folderId?: string) => {
    const newProject: Project = {
      id: uuidv4(),
      name,
      description,
      folderId,
      currentVersion: 0,
      config: {
        systemLimits: {
          maxTokens: 4000,
          temperature: 0.7,
          model: 'gpt-4-turbo-preview',
          responseFormat: 'markdown',
          timeout: 30,
          retryAttempts: 3
        },
        outputRequirements: {
          format: {
            type: 'structured',
            schema: {}
          },
          constraints: [],
          examples: [],
          validation: {
            required: [],
            optional: []
          }
        },
        testData: []
      },
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        tags: [],
        category: 'other'
      }
    }

    try {
      const db = await getDB()
      await db.add('projects', newProject)
      const projects = [...get().projects, newProject]
      set({ projects, currentProject: newProject })
      return newProject
    } catch (error) {
      console.error('Failed to create project:', error)
      throw error
    }
  },

  selectProject: (projectId: string) => {
    const project = get().projects.find(p => p.id === projectId)
    if (project) {
      set({ currentProject: project })
    }
  },

  updateProject: async (projectId: string, updates: Partial<Project>) => {
    try {
      const db = await getDB()
      const project = await db.get('projects', projectId)
      if (project) {
        const updatedProject = {
          ...project,
          ...updates,
          metadata: {
            ...project.metadata,
            updatedAt: new Date()
          }
        }
        await db.put('projects', updatedProject)
        const projects = get().projects.map(p => 
          p.id === projectId ? updatedProject : p
        )
        set({ 
          projects,
          currentProject: get().currentProject?.id === projectId ? updatedProject : get().currentProject
        })
      }
    } catch (error) {
      console.error('Failed to update project:', error)
      throw error
    }
  },

  deleteProject: async (projectId: string) => {
    try {
      const db = await getDB()
      await db.delete('projects', projectId)
      const projects = get().projects.filter(p => p.id !== projectId)
      set({ 
        projects,
        currentProject: get().currentProject?.id === projectId 
          ? (projects.length > 0 ? projects[0] : null)
          : get().currentProject
      })
    } catch (error) {
      console.error('Failed to delete project:', error)
      throw error
    }
  },

  createFolder: async (name: string, parentId?: string) => {
    const newFolder: Folder = {
      id: uuidv4(),
      name,
      parentId,
      collapsed: false,
      createdAt: new Date(),
      updatedAt: new Date()
    }

    try {
      const db = await getDB()
      await db.add('folders', newFolder)
      const folders = [...get().folders, newFolder]
      set({ folders })
      
      // 同步到本地文件
      setTimeout(() => get().syncStructureToLocal(), 100)
      
      return newFolder
    } catch (error) {
      console.error('Failed to create folder:', error)
      throw error
    }
  },

  updateFolder: async (folderId: string, updates: Partial<Folder>) => {
    try {
      const db = await getDB()
      const folder = await db.get('folders', folderId)
      if (folder) {
        const updatedFolder = {
          ...folder,
          ...updates,
          updatedAt: new Date()
        }
        await db.put('folders', updatedFolder)
        const folders = get().folders.map(f => 
          f.id === folderId ? updatedFolder : f
        )
        set({ folders })
        
        // 同步到本地文件
        setTimeout(() => get().syncStructureToLocal(), 100)
      }
    } catch (error) {
      console.error('Failed to update folder:', error)
      throw error
    }
  },

  deleteFolder: async (folderId: string, deleteProjects = false) => {
    try {
      const db = await getDB()
      
      // 如果需要删除内部项目
      if (deleteProjects) {
        const projectsInFolder = get().projects.filter(p => p.folderId === folderId)
        for (const project of projectsInFolder) {
          await db.delete('projects', project.id)
        }
        const remainingProjects = get().projects.filter(p => p.folderId !== folderId)
        set({ projects: remainingProjects })
      } else {
        // 将项目移出文件夹
        const projectsInFolder = get().projects.filter(p => p.folderId === folderId)
        for (const project of projectsInFolder) {
          const updatedProject = { ...project, folderId: undefined }
          await db.put('projects', updatedProject)
        }
        const projects = get().projects.map(p => 
          p.folderId === folderId ? { ...p, folderId: undefined } : p
        )
        set({ projects })
      }
      
      // 删除文件夹
      await db.delete('folders', folderId)
      const folders = get().folders.filter(f => f.id !== folderId)
      set({ folders })
      
      // 同步到本地文件
      setTimeout(() => get().syncStructureToLocal(), 100)
    } catch (error) {
      console.error('Failed to delete folder:', error)
      throw error
    }
  },

  toggleFolderCollapse: async (folderId: string) => {
    try {
      const db = await getDB()
      const folder = await db.get('folders', folderId)
      if (folder) {
        const updatedFolder = {
          ...folder,
          collapsed: !folder.collapsed,
          updatedAt: new Date()
        }
        await db.put('folders', updatedFolder)
        const folders = get().folders.map(f => 
          f.id === folderId ? updatedFolder : f
        )
        set({ folders })
        
        // 同步到本地文件
        setTimeout(() => get().syncStructureToLocal(), 100)
      }
    } catch (error) {
      console.error('Failed to toggle folder collapse:', error)
      throw error
    }
  },

  moveProjectToFolder: async (projectId: string, folderId: string | null) => {
    try {
      const db = await getDB()
      const project = await db.get('projects', projectId)
      if (project) {
        const updatedProject = {
          ...project,
          folderId: folderId || undefined,
          metadata: {
            ...project.metadata,
            updatedAt: new Date()
          }
        }
        await db.put('projects', updatedProject)
        const projects = get().projects.map(p => 
          p.id === projectId ? updatedProject : p
        )
        set({ 
          projects,
          currentProject: get().currentProject?.id === projectId ? updatedProject : get().currentProject
        })
        
        // 同步到本地文件
        setTimeout(() => get().syncStructureToLocal(), 100)
      }
    } catch (error) {
      console.error('Failed to move project to folder:', error)
      throw error
    }
  },

  restoreFromLocal: async () => {
    try {
      const response = await fetch('/api/load-local')
      const data: LoadLocalResponse = await response.json()
      
      if (!data.success || !data.projects || data.projects.length === 0) {
        console.log('No local projects to restore')
        return
      }
      
      const db = await getDB()
      
      // 获取现有项目和文件夹以保持UUID稳定性
      const existingProjects = new Map<string, Project>()
      const existingFolders = new Map<string, Folder>()
      
      try {
        const projects = await db.getAll('projects')
        projects.forEach(project => {
          existingProjects.set(project.name, project)
        })
        
        const folders = await db.getAll('folders')
        folders.forEach(folder => {
          existingFolders.set(folder.name, folder)
        })
      } catch (error) {
        console.log('Could not read existing data')
      }
      
      // 清除现有数据
      try {
        const projects = await db.getAll('projects')
        for (const project of projects) {
          await db.delete('projects', project.id)
        }
        
        const versions = await db.getAll('versions')
        for (const version of versions) {
          await db.delete('versions', version.id)
        }
        
        const folders = await db.getAll('folders')
        for (const folder of folders) {
          await db.delete('folders', folder.id)
        }
      } catch (error) {
        console.log('Could not clear existing data, continuing with restoration')
      }
      
      // 如果有结构配置，先恢复文件夹
      if (data.structure && data.structure.folders) {
        
        // 创建新文件夹，保持已有的UUID
        for (const localFolder of data.structure.folders) {
          const existingFolder = existingFolders.get(localFolder.name)
          const newFolder: Folder = {
            id: existingFolder ? existingFolder.id : localFolder.id,
            name: localFolder.name,
            parentId: localFolder.parentId,
            collapsed: existingFolder ? existingFolder.collapsed : false,
            createdAt: existingFolder ? existingFolder.createdAt : new Date(),
            updatedAt: new Date()
          }
          try {
            await db.add('folders', newFolder)
          } catch (error) {
            console.error('Failed to create folder:', localFolder.name)
          }
        }
      }
      
      for (const localProject of data.projects as LocalProject[]) {
        // 从结构配置中获取文件夹映射
        let folderId: string | undefined
        if (data.structure && data.structure.projectMappings) {
          folderId = data.structure.projectMappings[localProject.name] || undefined
        }
        
        // 创建项目，保持已有的UUID和配置
        const existingProject = existingProjects.get(localProject.name)
        const projectId = existingProject ? existingProject.id : uuidv4()
        const newProject: Project = {
          id: projectId,
          name: localProject.name,
          description: existingProject ? existingProject.description : `从本地备份恢复 (${localProject.versions.length} 个版本)`,
          folderId,
          currentVersion: localProject.versions.length > 0 
            ? localProject.versions[localProject.versions.length - 1].versionNumber 
            : 0,
          config: existingProject ? existingProject.config : {
            systemLimits: {
              maxTokens: 4000,
              temperature: 0.7,
              model: 'gpt-4-turbo-preview',
              responseFormat: 'markdown',
              timeout: 30,
              retryAttempts: 3
            },
            outputRequirements: {
              format: { type: 'structured', schema: {} },
              constraints: [],
              examples: [],
              validation: { required: [], optional: [] }
            },
            testData: []
          },
          metadata: {
            createdAt: existingProject ? existingProject.metadata.createdAt : new Date(),
            updatedAt: new Date(),
            tags: existingProject ? existingProject.metadata.tags : ['restored'],
            category: existingProject ? existingProject.metadata.category : 'other'
          }
        }
        
        await db.add('projects', newProject)
        
        // 创建版本
        for (const ver of localProject.versions) {
          const version: Version = {
            id: uuidv4(),
            projectId,
            versionNumber: ver.versionNumber,
            content: ver.content,
            timestamp: new Date(),
            description: `从本地文件恢复: ${ver.fileName}`,
            autoGenerated: false,
            metadata: {
              lines: ver.content.split('\n').length,
              characters: ver.content.length,
              words: ver.content.trim().split(/\s+/).filter(w => w.length > 0).length,
              changeType: 'minor'
            }
          }
          await db.add('versions', version)
        }
        
        console.log(`Restored project: ${localProject.name} with ${localProject.versions.length} versions`)
      }
      
      // 记录恢复时间戳
      try {
        await db.put('metadata', {
          key: 'lastRestore',
          value: new Date().toISOString()
        })
      } catch (error) {
        console.error('Failed to save restore timestamp:', error)
      }
    } catch (error) {
      console.error('Failed to restore from local:', error)
    }
  },

  syncStructureToLocal: async () => {
    try {
      const { projects, folders } = get()
      
      // 构建结构对象
      const structure: ProjectStructure = {
        version: "1.0.0",
        folders: folders.map(folder => ({
          id: folder.id,
          name: folder.name,
          parentId: folder.parentId
        })),
        projectMappings: {},
        lastUpdated: new Date().toISOString()
      }
      
      // 添加项目映射
      projects.forEach(project => {
        structure.projectMappings[project.name] = project.folderId || null
      })
      
      // 保存到本地
      const response = await fetch('/api/structure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ structure })
      })
      
      if (!response.ok) {
        throw new Error('Failed to sync structure to local file')
      }
      
      console.log('Structure synced to local file successfully')
    } catch (error) {
      console.error('Failed to sync structure to local:', error)
    }
  },

  needsRestoreFromLocal: async () => {
    try {
      const db = await getDB()
      
      // 检查是否有项目数据
      const projects = await db.getAll('projects')
      if (projects.length === 0) {
        console.log('No projects in IndexedDB, needs restore')
        return true
      }
      
      // 检查数据一致性：检测重复项目名称
      const projectNames = projects.map(p => p.name)
      const uniqueNames = new Set(projectNames)
      if (projectNames.length !== uniqueNames.size) {
        console.log('Duplicate projects detected, needs restore to fix inconsistency')
        return true
      }
      
      // 获取本地文件信息
      const response = await fetch('/api/load-local')
      const data: LoadLocalResponse = await response.json()
      
      if (!data.success || !data.lastModified) {
        console.log('Cannot get local file info, using existing data')
        return false
      }
      
      // 检查数据库中是否有 lastModified 记录
      try {
        const lastRestoreRecord = await db.get('metadata', 'lastRestore')
        if (lastRestoreRecord && lastRestoreRecord.value) {
          const lastRestoreTime = lastRestoreRecord.value
          const localFileTime = new Date(data.lastModified)
          const dbTime = new Date(lastRestoreTime)
          
          if (localFileTime > dbTime) {
            console.log('Local files are newer, needs restore')
            return true
          }
        } else {
          console.log('No restore timestamp found, needs restore')
          return true
        }
      } catch (error) {
        console.log('Cannot check timestamp, needs restore')
        return true
      }
      
      console.log('IndexedDB data is up to date')
      return false
    } catch (error) {
      console.error('Error checking restore needs:', error)
      return true // 出错时保守选择恢复
    }
  }
}))