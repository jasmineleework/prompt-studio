import { create } from 'zustand'
import { TradingConfig, AIConfig } from '@/types/trading'
import { DEFAULT_TRADING_CONFIG } from '@/lib/constants/defaultConfigs'

interface ConfigState {
  config: TradingConfig
  hasChanges: boolean
  
  setSystemConstraints: (constraints: string) => void
  setOutputFormat: (format: string) => void
  setEnabled: (enabled: boolean) => void
  setAIConfig: (aiConfig: AIConfig) => void
  updateAIConfig: (updates: Partial<AIConfig>) => void
  saveConfig: () => void
  resetConfig: () => void
  loadConfig: (config: TradingConfig) => void
}

export const useConfigStore = create<ConfigState>((set, get) => ({
  config: DEFAULT_TRADING_CONFIG,
  hasChanges: false,
  
  setSystemConstraints: (constraints: string) => {
    set(state => ({
      config: {
        ...state.config,
        systemConstraints: constraints
      },
      hasChanges: true
    }))
  },
  
  setOutputFormat: (format: string) => {
    set(state => ({
      config: {
        ...state.config,
        outputFormat: format
      },
      hasChanges: true
    }))
  },
  
  setEnabled: (enabled: boolean) => {
    set(state => ({
      config: {
        ...state.config,
        enabled
      },
      hasChanges: true
    }))
  },

  setAIConfig: (aiConfig: AIConfig) => {
    set(state => ({
      config: {
        ...state.config,
        aiConfig
      },
      hasChanges: true
    }))
  },

  updateAIConfig: (updates: Partial<AIConfig>) => {
    set(state => ({
      config: {
        ...state.config,
        aiConfig: state.config.aiConfig 
          ? { ...state.config.aiConfig, ...updates }
          : { ...DEFAULT_TRADING_CONFIG.aiConfig!, ...updates }
      },
      hasChanges: true
    }))
  },
  
  saveConfig: () => {
    // 这里可以添加保存到 IndexedDB 的逻辑
    set({ hasChanges: false })
  },
  
  resetConfig: () => {
    set({
      config: DEFAULT_TRADING_CONFIG,
      hasChanges: false
    })
  },
  
  loadConfig: (config: TradingConfig) => {
    set({
      config,
      hasChanges: false
    })
  }
}))