import { Conflict, ConflictAnalysis, Suggestion } from '@/types/trading'
import { CONFLICT_RULES } from '@/lib/constants/defaultConfigs'
import { v4 as uuidv4 } from 'uuid'

export class ConflictAnalyzer {
  /**
   * 分析Prompt与系统规则的冲突
   */
  analyzePrompt(
    userPrompt: string,
    systemConstraints: string,
    outputFormat: string
  ): ConflictAnalysis {
    const conflicts: Conflict[] = []
    const suggestions: Suggestion[] = []
    
    // 1. 检查仓位管理规则
    this.checkPositionRules(userPrompt, conflicts, suggestions)
    
    // 2. 检查风险管理规则
    this.checkRiskRules(userPrompt, conflicts, suggestions)
    
    // 3. 检查杠杆规则
    this.checkLeverageRules(userPrompt, conflicts, suggestions)
    
    // 4. 检查输出格式
    this.checkOutputFormat(userPrompt, outputFormat, conflicts, suggestions)
    
    // 5. 去重相同的建议（避免重复建议）
    const uniqueSuggestions = this.deduplicateSuggestions(suggestions)
    
    // 6. 计算评分
    const score = this.calculateScore(conflicts)
    
    return {
      timestamp: new Date(),
      conflicts,
      suggestions: uniqueSuggestions,
      score
    }
  }
  
  private checkPositionRules(
    prompt: string,
    conflicts: Conflict[],
    suggestions: Suggestion[]
  ) {
    // 检查加仓相关
    const addPositionKeywords = ['加仓', '分批建仓', '逐步建仓', '金字塔', 'pyramid', 'scale in']
    for (const keyword of addPositionKeywords) {
      const occurrences = this.findAllOccurrences(prompt, keyword)
      for (const index of occurrences) {
        conflicts.push({
          id: uuidv4(),
          type: 'position',
          severity: 'error',
          userText: this.extractContext(prompt, keyword, index),
          systemRule: '禁止加仓',
          explanation: '系统不允许加仓操作，所有仓位必须一次性建立',
          lineNumber: this.findLineNumber(prompt, keyword, index)
        })
        
        suggestions.push({
          id: uuidv4(),
          type: 'fix',
          title: '移除加仓策略',
          description: '将加仓策略改为一次性开仓',
          oldText: keyword,
          newText: '一次性开仓',
          impact: 'high'
        })
      }
    }
    
    // 检查对冲相关
    const hedgingKeywords = ['对冲', 'hedging', 'hedge', '同时做多做空', '多空双开']
    for (const keyword of hedgingKeywords) {
      const occurrences = this.findAllOccurrences(prompt, keyword)
      for (const index of occurrences) {
        conflicts.push({
          id: uuidv4(),
          type: 'position',
          severity: 'error',
          userText: this.extractContext(prompt, keyword, index),
          systemRule: '禁止hedging',
          explanation: '同一币种不能同时持有多空仓位',
          lineNumber: this.findLineNumber(prompt, keyword, index)
        })
        
        suggestions.push({
          id: uuidv4(),
          type: 'fix',
          title: '移除对冲策略',
          description: '移除对冲相关的交易策略',
          oldText: keyword,
          newText: '单向持仓',
          impact: 'high'
        })
      }
    }
    
    // 检查部分平仓
    const partialCloseKeywords = ['部分平仓', '分批平仓', '部分止盈', 'partial close', 'scale out']
    for (const keyword of partialCloseKeywords) {
      const occurrences = this.findAllOccurrences(prompt, keyword)
      for (const index of occurrences) {
        conflicts.push({
          id: uuidv4(),
          type: 'position',
          severity: 'error',
          userText: this.extractContext(prompt, keyword, index),
          systemRule: '禁止部分平仓',
          explanation: '必须完全平仓，不能部分平仓',
          lineNumber: this.findLineNumber(prompt, keyword, index)
        })
        
        suggestions.push({
          id: uuidv4(),
          type: 'fix',
          title: '修改平仓策略',
          description: '改为完全平仓策略',
          oldText: keyword,
          newText: '完全平仓',
          impact: 'high'
        })
      }
    }
  }
  
  private checkRiskRules(
    prompt: string,
    conflicts: Conflict[],
    suggestions: Suggestion[]
  ) {
    const lowerPrompt = prompt.toLowerCase()
    
    // 检查止损
    const hasStopLoss = lowerPrompt.includes('止损') || 
                       lowerPrompt.includes('stop loss') || 
                       lowerPrompt.includes('stop-loss') ||
                       lowerPrompt.includes('sl')
                       
    if (!hasStopLoss) {
      conflicts.push({
        id: uuidv4(),
        type: 'risk',
        severity: 'warning',
        userText: '未发现止损设置说明',
        systemRule: '必须设置止损',
        explanation: '所有开仓必须包含止损价格设置'
      })
      
      suggestions.push({
        id: uuidv4(),
        type: 'improvement',
        title: '添加止损说明',
        description: '在策略中明确说明止损设置规则',
        impact: 'high'
      })
    }
    
    // 检查止盈
    const hasTakeProfit = lowerPrompt.includes('止盈') || 
                         lowerPrompt.includes('take profit') || 
                         lowerPrompt.includes('tp') ||
                         lowerPrompt.includes('profit target')
                         
    if (!hasTakeProfit) {
      conflicts.push({
        id: uuidv4(),
        type: 'risk',
        severity: 'warning',
        userText: '未发现止盈设置说明',
        systemRule: '必须设置止盈',
        explanation: '所有开仓必须包含止盈价格设置'
      })
      
      suggestions.push({
        id: uuidv4(),
        type: 'improvement',
        title: '添加止盈说明',
        description: '在策略中明确说明止盈设置规则',
        impact: 'high'
      })
    }
  }
  
  private checkLeverageRules(
    prompt: string,
    conflicts: Conflict[],
    suggestions: Suggestion[]
  ) {
    // 检查超过20倍杠杆
    const highLeveragePattern = /(\d+)[倍x]\s*杠杆/gi
    const matches = Array.from(prompt.matchAll(highLeveragePattern))
    
    for (const match of matches) {
      const leverage = parseInt(match[1])
      if (leverage > 20) {
        // 使用match.index来获取准确的位置信息
        const matchIndex = match.index || 0
        const beforeMatch = prompt.substring(0, matchIndex)
        const lineNumber = beforeMatch.split('\n').length
        
        conflicts.push({
          id: uuidv4(),
          type: 'leverage',
          severity: 'error',
          userText: match[0],
          systemRule: '最大杠杆20倍',
          explanation: `检测到${leverage}倍杠杆，超过系统最大限制20倍`,
          lineNumber: lineNumber
        })
        
        suggestions.push({
          id: uuidv4(),
          type: 'fix',
          title: '调整杠杆倍数',
          description: '将杠杆调整为20倍或以下',
          oldText: match[0],
          newText: '20倍杠杆',
          impact: 'high'
        })
      }
    }
  }
  
  private checkOutputFormat(
    prompt: string,
    outputFormat: string,
    conflicts: Conflict[],
    suggestions: Suggestion[]
  ) {
    // 检查是否与系统要求的格式冲突
    const conflictingFormats = ['csv', 'excel', 'table', 'xml', 'yaml', 'txt']
    
    for (const format of conflictingFormats) {
      const occurrences = this.findAllOccurrences(prompt, format)
      for (const index of occurrences) {
        conflicts.push({
          id: uuidv4(),
          type: 'output',
          severity: 'warning',
          userText: this.extractContext(prompt, format, index),
          systemRule: '必须使用JSON格式',
          explanation: `检测到${format.toUpperCase()}格式要求，但系统要求使用标准JSON格式输出交易信号`,
          lineNumber: this.findLineNumber(prompt, format, index)
        })
        
        suggestions.push({
          id: uuidv4(),
          type: 'fix',
          title: '修改输出格式',
          description: '改为使用JSON格式输出',
          oldText: format,
          newText: 'JSON',
          impact: 'medium'
        })
      }
    }
  }
  
  private extractContext(text: string, keyword: string, startIndex: number = 0, contextLength: number = 50): string {
    const lowerText = text.toLowerCase()
    const lowerKeyword = keyword.toLowerCase()
    const index = lowerText.indexOf(lowerKeyword, startIndex)
    if (index === -1) return keyword
    
    const start = Math.max(0, index - contextLength)
    const end = Math.min(text.length, index + keyword.length + contextLength)
    
    let context = text.substring(start, end)
    if (start > 0) context = '...' + context
    if (end < text.length) context = context + '...'
    
    return context
  }
  
  private findLineNumber(text: string, keyword: string, startIndex: number = 0): number | undefined {
    const lowerText = text.toLowerCase()
    const lowerKeyword = keyword.toLowerCase()
    const index = lowerText.indexOf(lowerKeyword, startIndex)
    if (index === -1) return undefined
    
    const beforeIndex = text.substring(0, index)
    const lineNumber = beforeIndex.split('\n').length
    return lineNumber
  }
  
  private findAllOccurrences(text: string, keyword: string): number[] {
    const indices: number[] = []
    const lowerText = text.toLowerCase()
    const lowerKeyword = keyword.toLowerCase()
    
    let index = lowerText.indexOf(lowerKeyword)
    while (index !== -1) {
      indices.push(index)
      index = lowerText.indexOf(lowerKeyword, index + 1)
    }
    
    return indices
  }
  
  private deduplicateSuggestions(suggestions: Suggestion[]): Suggestion[] {
    const uniqueSuggestions = new Map<string, Suggestion>()
    
    for (const suggestion of suggestions) {
      const key = `${suggestion.type}-${suggestion.title}-${suggestion.oldText}-${suggestion.newText}`
      if (!uniqueSuggestions.has(key)) {
        uniqueSuggestions.set(key, suggestion)
      }
    }
    
    return Array.from(uniqueSuggestions.values())
  }
  
  private calculateScore(conflicts: Conflict[]): ConflictAnalysis['score'] {
    const errorCount = conflicts.filter(c => c.severity === 'error').length
    const warningCount = conflicts.filter(c => c.severity === 'warning').length
    
    let compatibility = 100
    compatibility -= errorCount * 20
    compatibility -= warningCount * 10
    compatibility = Math.max(0, compatibility)
    
    let severity: 'low' | 'medium' | 'high'
    if (errorCount > 0) {
      severity = 'high'
    } else if (warningCount > 2) {
      severity = 'medium'
    } else {
      severity = 'low'
    }
    
    return { compatibility, severity }
  }
}

export const conflictAnalyzer = new ConflictAnalyzer()