import { TradingConfig, AIConfig } from '@/types/trading'

export const DEFAULT_SYSTEM_CONSTRAINTS = `系统限制：
- 同一币种仅允许持有1个仓位，不允许hedging（同一币对同时持有多仓和空仓）
- 禁止加仓
- 禁止部分平仓，只能完全平仓
- 开仓必须有止盈止损
- 每个coin必须输出signal
- 信号币种必须在支持币种范围内
- 开仓杠杆必须小于等于最大杠杆设置（20倍）
- 开仓后的持仓数量必须小于最大持仓数量（5个）`

export const DEFAULT_OUTPUT_FORMAT = `输出要求：
Signal格式：
{
  "action": "open_long" | "open_short" | "hold" | "close" | "wait",
  "coin": "BTC",  // 币种符号
  "quantity": 0.5,  // 仓位数量
  "leverage": 10,  // 杠杆倍数 (1-20)
  "profit_target": 50000,  // 止盈价格
  "stop_loss": 45000,  // 止损价格
  "confidence": 0.75,  // 置信度 (0-1)
  "risk_usd": 500,  // 风险金额 = |Entry Price - Stop Loss| × Quantity × Leverage
  "invalidation_condition": "价格跌破45000",  // 失效条件
  "reasoning": "基于技术指标和市场情绪..."  // 解释（最多500字符）
}`

export const DEFAULT_AI_CONFIG: AIConfig = {
  enabled: false,
  provider: 'deepseek',
  apiKey: '',
  baseURL: 'https://api.deepseek.com/v1',
  model: 'deepseek-chat',
  temperature: 0.1,
  maxTokens: 8000
}

export const DEFAULT_TRADING_CONFIG: TradingConfig = {
  systemConstraints: DEFAULT_SYSTEM_CONSTRAINTS,
  outputFormat: DEFAULT_OUTPUT_FORMAT,
  enabled: true,
  aiConfig: DEFAULT_AI_CONFIG
}

// 支持的币种列表
export const SUPPORTED_COINS = [
  'BTC', 'ETH', 'BNB', 'SOL', 'ADA', 
  'DOGE', 'XRP', 'DOT', 'AVAX', 'MATIC',
  'LINK', 'UNI', 'ATOM', 'LTC', 'ETC'
]

// 冲突检查规则
export const CONFLICT_RULES = {
  position: [
    { keyword: '加仓', rule: '禁止加仓' },
    { keyword: '分批建仓', rule: '禁止加仓' },
    { keyword: '逐步建仓', rule: '禁止加仓' },
    { keyword: '金字塔', rule: '禁止加仓' },
    { keyword: '对冲', rule: '禁止hedging' },
    { keyword: 'hedging', rule: '禁止hedging' },
    { keyword: '同时做多做空', rule: '禁止hedging' },
    { keyword: '部分平仓', rule: '禁止部分平仓' },
    { keyword: '分批平仓', rule: '禁止部分平仓' },
    { keyword: '部分止盈', rule: '禁止部分平仓' }
  ],
  risk: [
    { keyword: '止损', required: true, rule: '必须设置止损' },
    { keyword: 'stop loss', required: true, rule: '必须设置止损' },
    { keyword: '止盈', required: true, rule: '必须设置止盈' },
    { keyword: 'take profit', required: true, rule: '必须设置止盈' },
    { keyword: 'profit target', required: true, rule: '必须设置止盈' }
  ],
  leverage: [
    { keyword: '30倍', rule: '最大杠杆20倍' },
    { keyword: '50倍', rule: '最大杠杆20倍' },
    { keyword: '100倍', rule: '最大杠杆20倍' },
    { keyword: '25x', rule: '最大杠杆20倍' },
    { keyword: '30x', rule: '最大杠杆20倍' }
  ]
}