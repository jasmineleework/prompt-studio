'use client'

import { useVersionStore } from '@/lib/stores/versionStore'
import { useProjectStore } from '@/lib/stores/projectStore'
import { Clock, GitBranch, RotateCcw } from 'lucide-react'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'

export function VersionPanel() {
  const { currentProject } = useProjectStore()
  const { versions, currentVersion, selectVersion } = useVersionStore()

  if (!currentProject) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <p className="text-sm">No project selected</p>
      </div>
    )
  }

  const projectVersions = versions.filter(v => v.projectId === currentProject.id)

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-border">
        <h3 className="text-sm font-medium flex items-center gap-2">
          <GitBranch className="h-4 w-4" />
          Version History
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto">
        {projectVersions.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            <p className="text-sm">No versions yet</p>
            <p className="text-xs mt-2">Start editing to create versions</p>
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {projectVersions.map((version) => (
              <button
                key={version.id}
                onClick={() => selectVersion(version.id)}
                className={cn(
                  "w-full text-left p-3 rounded border transition-colors",
                  currentVersion?.id === version.id
                    ? "border-primary bg-primary/5"
                    : "border-border hover:bg-accent"
                )}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">v{version.versionNumber}</span>
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(version.timestamp), 'HH:mm')}
                  </span>
                </div>
                <div className="text-xs text-muted-foreground space-y-0.5">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {format(new Date(version.timestamp), 'MMM d, yyyy')}
                  </div>
                  {version.description && (
                    <p className="truncate">{version.description}</p>
                  )}
                  <div className="flex gap-3">
                    <span>{version.metadata.lines} lines</span>
                    <span>{version.metadata.words} words</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {projectVersions.length > 1 && (
        <div className="p-3 border-t border-border space-y-2">
          <button className="w-full py-1.5 px-3 text-sm border border-border rounded hover:bg-accent flex items-center justify-center gap-2">
            <RotateCcw className="h-3 w-3" />
            Compare Versions
          </button>
        </div>
      )}
    </div>
  )
}