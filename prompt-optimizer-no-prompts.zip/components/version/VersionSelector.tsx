'use client'

import { useState, useRef, useEffect } from 'react'
import { ChevronDown, Clock, Check } from 'lucide-react'
import { useVersionStore } from '@/lib/stores/versionStore'
import { useProjectStore } from '@/lib/stores/projectStore'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'

export function VersionSelector() {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const { currentProject } = useProjectStore()
  const { versions, currentVersion, selectVersion } = useVersionStore()
  
  const projectVersions = versions.filter(v => v.projectId === currentProject?.id)
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])
  
  if (!currentProject || projectVersions.length === 0) {
    return (
      <div className="px-3 py-1.5 text-sm text-muted-foreground">
        无版本
      </div>
    )
  }
  
  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 text-sm border border-border rounded hover:bg-accent"
      >
        <span className="font-medium">
          v{currentVersion?.versionNumber || '1'}
        </span>
        <span className="text-xs text-muted-foreground">
          {currentVersion && format(new Date(currentVersion.timestamp), 'HH:mm')}
        </span>
        <ChevronDown className={cn(
          "h-3 w-3 transition-transform",
          isOpen && "rotate-180"
        )} />
      </button>
      
      {isOpen && (
        <div className="absolute top-full mt-1 w-72 max-h-96 overflow-y-auto bg-background border border-border rounded-lg shadow-lg z-50">
          <div className="p-2">
            <div className="text-xs font-medium text-muted-foreground px-2 py-1">
              版本历史
            </div>
            <div className="space-y-1">
              {projectVersions.map((version) => (
                <button
                  key={version.id}
                  onClick={() => {
                    selectVersion(version.id)
                    setIsOpen(false)
                  }}
                  className={cn(
                    "w-full text-left px-2 py-2 rounded hover:bg-accent transition-colors",
                    currentVersion?.id === version.id && "bg-accent"
                  )}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">
                          v{version.versionNumber}
                        </span>
                        {currentVersion?.id === version.id && (
                          <Check className="h-3 w-3 text-primary" />
                        )}
                      </div>
                      {version.description && (
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                          {version.description}
                        </p>
                      )}
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(version.timestamp), 'MM/dd HH:mm')}
                        </span>
                        <span>{version.metadata.words} 字</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}