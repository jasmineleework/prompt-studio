'use client'

import { useState } from 'react'
import { useConfigStore } from '@/lib/stores/configStore'
import { AIConfig } from '@/types/trading'
import { Eye, EyeOff, Key, Globe, Cpu, ToggleLeft, ToggleRight } from 'lucide-react'
import { cn } from '@/lib/utils'

interface AIConfigProps {
  onSave: () => void
}

export function AIConfig({ onSave }: AIConfigProps) {
  const { config, updateAIConfig } = useConfigStore()
  const [showApiKey, setShowApiKey] = useState(false)
  
  const aiConfig = config.aiConfig || {
    enabled: false,
    provider: 'deepseek' as const,
    apiKey: '',
    baseURL: 'https://api.deepseek.com/v1',
    model: 'deepseek-chat',
    temperature: 0.1,
    maxTokens: 4000
  }

  const handleConfigChange = (updates: Partial<AIConfig>) => {
    updateAIConfig(updates)
  }

  const providers = [
    { 
      value: 'deepseek' as const, 
      label: 'DeepSeek', 
      baseURL: 'https://api.deepseek.com/v1',
      defaultModel: 'deepseek-chat'
    },
    { 
      value: 'openai' as const, 
      label: 'OpenAI', 
      baseURL: 'https://api.openai.com/v1',
      defaultModel: 'gpt-4-turbo-preview'
    }
  ]

  const handleProviderChange = (provider: 'openai' | 'deepseek') => {
    const providerConfig = providers.find(p => p.value === provider)
    if (providerConfig) {
      handleConfigChange({
        provider,
        baseURL: providerConfig.baseURL,
        model: providerConfig.defaultModel
      })
    }
  }

  return (
    <div className="space-y-4 text-sm">
      {/* 启用开关 */}
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2">
          <Key className="h-3 w-3" />
          <span>启用AI检测</span>
        </label>
        <button
          onClick={() => handleConfigChange({ enabled: !aiConfig.enabled })}
          className="p-0.5"
        >
          {aiConfig.enabled ? (
            <ToggleRight className="h-4 w-4 text-primary" />
          ) : (
            <ToggleLeft className="h-4 w-4 text-muted-foreground" />
          )}
        </button>
      </div>

      {aiConfig.enabled && (
        <>
          {/* 服务商选择 */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-xs font-medium">
              <Cpu className="h-3 w-3" />
              AI服务商
            </label>
            <div className="flex gap-2">
              {providers.map((provider) => (
                <button
                  key={provider.value}
                  onClick={() => handleProviderChange(provider.value)}
                  className={cn(
                    "px-3 py-1.5 text-xs rounded border transition-colors",
                    aiConfig.provider === provider.value
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border hover:bg-accent"
                  )}
                >
                  {provider.label}
                </button>
              ))}
            </div>
          </div>

          {/* API密钥 */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-xs font-medium">
              <Key className="h-3 w-3" />
              API密钥
            </label>
            <div className="relative">
              <input
                type={showApiKey ? 'text' : 'password'}
                value={aiConfig.apiKey}
                onChange={(e) => handleConfigChange({ apiKey: e.target.value })}
                placeholder="请输入API密钥"
                className="w-full px-3 py-1.5 text-xs bg-background border border-input rounded pr-8"
              />
              <button
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 p-0.5 hover:bg-accent rounded"
              >
                {showApiKey ? (
                  <EyeOff className="h-3 w-3" />
                ) : (
                  <Eye className="h-3 w-3" />
                )}
              </button>
            </div>
          </div>

          {/* 基础URL */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-xs font-medium">
              <Globe className="h-3 w-3" />
              API基础URL
            </label>
            <input
              type="url"
              value={aiConfig.baseURL || ''}
              onChange={(e) => handleConfigChange({ baseURL: e.target.value })}
              placeholder="API基础URL"
              className="w-full px-3 py-1.5 text-xs bg-background border border-input rounded"
            />
          </div>

          {/* 模型名称 */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-xs font-medium">
              <Cpu className="h-3 w-3" />
              模型名称
            </label>
            <input
              type="text"
              value={aiConfig.model}
              onChange={(e) => handleConfigChange({ model: e.target.value })}
              placeholder="模型名称"
              className="w-full px-3 py-1.5 text-xs bg-background border border-input rounded"
            />
          </div>

          {/* 高级设置 */}
          <details className="space-y-2">
            <summary className="text-xs font-medium cursor-pointer hover:text-primary">
              高级设置
            </summary>
            <div className="pl-4 space-y-3">
              {/* 温度 */}
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground">
                  温度 ({aiConfig.temperature || 0.1})
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={aiConfig.temperature || 0.1}
                  onChange={(e) => handleConfigChange({ temperature: parseFloat(e.target.value) })}
                  className="w-full"
                />
              </div>

              {/* 最大Tokens */}
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground">最大Tokens</label>
                <input
                  type="number"
                  min="1000"
                  max="8000"
                  value={aiConfig.maxTokens || 4000}
                  onChange={(e) => handleConfigChange({ maxTokens: parseInt(e.target.value) })}
                  className="w-full px-2 py-1 text-xs bg-background border border-input rounded"
                />
              </div>
            </div>
          </details>

          {/* 保存按钮 */}
          <button
            onClick={onSave}
            className="w-full px-3 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90"
          >
            保存AI配置
          </button>

          {/* 状态提示 */}
          {aiConfig.apiKey.trim() && (
            <div className="p-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded text-xs">
              <p className="text-green-700 dark:text-green-300">
                ✅ AI检测已配置，将优先使用AI进行冲突检测
              </p>
            </div>
          )}
          
          {!aiConfig.apiKey.trim() && (
            <div className="p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded text-xs">
              <p className="text-yellow-700 dark:text-yellow-300">
                ⚠️ 请配置API密钥以启用AI检测功能
              </p>
            </div>
          )}
        </>
      )}
    </div>
  )
}