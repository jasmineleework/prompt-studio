'use client'

import { useState, useEffect } from 'react'
import { Shield, RotateCcw, Save } from 'lucide-react'
import { DEFAULT_SYSTEM_CONSTRAINTS } from '@/lib/constants/defaultConfigs'
import { cn } from '@/lib/utils'

interface SystemConstraintsProps {
  value: string
  onChange: (value: string) => void
  onSave?: () => void
}

export function SystemConstraints({ value, onChange, onSave }: SystemConstraintsProps) {
  const [localValue, setLocalValue] = useState(value || DEFAULT_SYSTEM_CONSTRAINTS)
  const [hasChanges, setHasChanges] = useState(false)

  useEffect(() => {
    setLocalValue(value || DEFAULT_SYSTEM_CONSTRAINTS)
  }, [value])

  const handleChange = (newValue: string) => {
    setLocalValue(newValue)
    setHasChanges(newValue !== value)
  }

  const handleSave = () => {
    onChange(localValue)
    setHasChanges(false)
    onSave?.()
  }

  const handleReset = () => {
    setLocalValue(DEFAULT_SYSTEM_CONSTRAINTS)
    setHasChanges(DEFAULT_SYSTEM_CONSTRAINTS !== value)
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">系统限制</span>
        </div>
        <div className="flex items-center gap-2">
          {hasChanges && (
            <span className="text-xs text-orange-500">有未保存的更改</span>
          )}
        </div>
      </div>

      <textarea
        value={localValue}
        onChange={(e) => handleChange(e.target.value)}
        className="w-full h-48 px-3 py-2 text-xs font-mono bg-background border border-input rounded resize-none focus:outline-none focus:ring-1 focus:ring-ring"
        placeholder="输入系统限制规则..."
      />

      <div className="flex justify-between">
        <button
          onClick={handleReset}
          className="px-3 py-1.5 text-xs border border-border rounded hover:bg-accent flex items-center gap-1"
        >
          <RotateCcw className="h-3 w-3" />
          恢复默认
        </button>
        
        <button
          onClick={handleSave}
          disabled={!hasChanges}
          className={cn(
            "px-3 py-1.5 text-xs rounded flex items-center gap-1",
            hasChanges
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
        >
          <Save className="h-3 w-3" />
          保存配置
        </button>
      </div>
    </div>
  )
}