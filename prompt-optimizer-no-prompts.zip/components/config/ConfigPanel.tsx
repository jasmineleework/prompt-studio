'use client'

import { useState } from 'react'
import { Settings, ChevronRight, ChevronDown, Shield, FileJson, ToggleLeft, ToggleRight, Brain } from 'lucide-react'
import { SystemConstraints } from './SystemConstraints'
import { OutputFormat } from './OutputFormat'
import { AIConfig } from './AIConfig'
import { useConfigStore } from '@/lib/stores/configStore'
import { cn } from '@/lib/utils'

export function ConfigPanel() {
  const [activeTab, setActiveTab] = useState<'limits' | 'output' | 'ai' | null>(null)
  const { config, setSystemConstraints, setOutputFormat, setEnabled, saveConfig } = useConfigStore()

  return (
    <div className="flex flex-col flex-1">
      <div className="p-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium flex items-center gap-2">
            <Settings className="h-4 w-4" />
            配置管理
          </h3>
          <button
            onClick={() => setEnabled(!config.enabled)}
            className="p-1"
            title={config.enabled ? '点击禁用配置' : '点击启用配置'}
          >
            {config.enabled ? (
              <ToggleRight className="h-5 w-5 text-primary" />
            ) : (
              <ToggleLeft className="h-5 w-5 text-muted-foreground" />
            )}
          </button>
        </div>
        {!config.enabled && (
          <p className="text-xs text-muted-foreground mt-1">配置已禁用</p>
        )}
      </div>

      <div className={cn("flex-1 overflow-y-auto", !config.enabled && "opacity-50 pointer-events-none")}>
        <div className="p-2">
          {/* System Limits */}
          <button
            onClick={() => setActiveTab(activeTab === 'limits' ? null : 'limits')}
            className="w-full flex items-center gap-2 px-2 py-1.5 text-sm rounded hover:bg-accent"
          >
            {activeTab === 'limits' ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <Shield className="h-4 w-4" />
            系统限制
          </button>
          {activeTab === 'limits' && (
            <div className="mt-2 px-2">
              <SystemConstraints
                value={config.systemConstraints}
                onChange={setSystemConstraints}
                onSave={saveConfig}
              />
            </div>
          )}

          {/* Output Format */}
          <button
            onClick={() => setActiveTab(activeTab === 'output' ? null : 'output')}
            className="w-full flex items-center gap-2 px-2 py-1.5 text-sm rounded hover:bg-accent mt-1"
          >
            {activeTab === 'output' ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <FileJson className="h-4 w-4" />
            输出格式
          </button>
          {activeTab === 'output' && (
            <div className="mt-2 px-2">
              <OutputFormat
                value={config.outputFormat}
                onChange={setOutputFormat}
                onSave={saveConfig}
              />
            </div>
          )}

          {/* AI Configuration */}
          <button
            onClick={() => setActiveTab(activeTab === 'ai' ? null : 'ai')}
            className="w-full flex items-center gap-2 px-2 py-1.5 text-sm rounded hover:bg-accent mt-1"
          >
            {activeTab === 'ai' ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <Brain className="h-4 w-4" />
            AI设置
            {config.aiConfig?.enabled && config.aiConfig?.apiKey && (
              <div className="w-2 h-2 bg-green-500 rounded-full ml-auto" />
            )}
          </button>
          {activeTab === 'ai' && (
            <div className="mt-2 px-2">
              <AIConfig onSave={saveConfig} />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}