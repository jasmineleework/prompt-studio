'use client'

import { useEffect, useRef } from 'react'
import Editor from '@monaco-editor/react'
import { useProjectStore } from '@/lib/stores/projectStore'
import { useVersionStore } from '@/lib/stores/versionStore'
import { useEditorStore } from '@/lib/stores/editorStore'
import { EditorToolbar } from './EditorToolbar'

export function PromptEditor() {
  const { currentProject } = useProjectStore()
  const { currentVersion, loadVersions } = useVersionStore()
  const { content, setContent, loadContent } = useEditorStore()
  const editorRef = useRef<any>(null)

  // Load versions when project changes
  useEffect(() => {
    if (currentProject) {
      loadVersions(currentProject.id)
    }
  }, [currentProject, loadVersions])

  // Update content when version changes
  useEffect(() => {
    if (currentVersion) {
      loadContent(currentVersion.content)
    } else {
      loadContent('')
    }
  }, [currentVersion, loadContent])

  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setContent(value)
    }
  }

  if (!currentProject) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <div className="text-center">
          <p className="text-lg mb-2">No project selected</p>
          <p className="text-sm">Create or select a project to start editing</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      <EditorToolbar />
      <div className="flex-1 relative">
        <Editor
          height="100%"
          defaultLanguage="markdown"
          value={content}
          onChange={handleEditorChange}
          onMount={(editor) => {
            editorRef.current = editor
          }}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            wordWrap: 'on',
            lineNumbers: 'on',
            renderLineHighlight: 'none',
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 2,
            theme: 'vs-dark'
          }}
        />
      </div>
    </div>
  )
}