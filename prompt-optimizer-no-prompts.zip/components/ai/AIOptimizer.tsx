'use client'

import { useState } from 'react'
import { Sparkles, AlertCircle, CheckCircle, Loader, Search } from 'lucide-react'
import { useEditorStore } from '@/lib/stores/editorStore'
import { useConfigStore } from '@/lib/stores/configStore'
import { ConflictAnalysis } from '@/types/trading'
import { cn } from '@/lib/utils'

export function AIOptimizer() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<ConflictAnalysis | null>(null)
  const { content } = useEditorStore()
  const { config } = useConfigStore()

  const handleCheckConflicts = async () => {
    if (!content) {
      alert('请先编写Prompt内容')
      return
    }
    
    setIsAnalyzing(true)
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: content,
          config: config
        })
      })
      
      const data = await response.json()
      if (data.success && data.analysis) {
        setAnalysisResult(data.analysis)
      } else {
        console.error('分析失败:', data.error)
      }
    } catch (error) {
      console.error('请求失败:', error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
          <Sparkles className="h-4 w-4" />
          AI 分析优化
        </h3>
        <div className="flex flex-col gap-2">
          <button
            onClick={handleCheckConflicts}
            disabled={isAnalyzing}
            className="w-full px-3 py-2 text-sm border border-border rounded hover:bg-accent flex items-center justify-center gap-2 transition-colors"
            title="检查与系统规则的冲突"
          >
            {isAnalyzing ? (
              <Loader className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
            检查冲突
          </button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {analysisResult && (
          <div className="space-y-4">
            {/* 分析概览 */}
            <div className="p-4 border rounded-lg bg-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">分析结果</span>
                <span className={cn(
                  "text-xs px-2 py-1 rounded-full",
                  analysisResult.score.severity === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900/20' :
                  analysisResult.score.severity === 'medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20' :
                  'bg-green-100 text-green-700 dark:bg-green-900/20'
                )}>
                  {analysisResult.score.severity === 'high' ? '严重' :
                   analysisResult.score.severity === 'medium' ? '中等' : '良好'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="text-center p-2 bg-background rounded">
                  <div className="text-2xl font-bold text-primary">{analysisResult.score.compatibility}%</div>
                  <div className="text-muted-foreground">兼容性</div>
                </div>
                <div className="text-center p-2 bg-background rounded">
                  <div className="text-2xl font-bold text-orange-500">{analysisResult.conflicts.length}</div>
                  <div className="text-muted-foreground">问题</div>
                </div>
                <div className="text-center p-2 bg-background rounded">
                  <div className="text-2xl font-bold text-blue-500">{analysisResult.suggestions.length}</div>
                  <div className="text-muted-foreground">建议</div>
                </div>
              </div>
            </div>

            {/* 冲突列表 */}
            {analysisResult.conflicts.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-medium text-muted-foreground">发现的冲突</h4>
                {analysisResult.conflicts.map((conflict) => (
                  <div key={conflict.id} className="p-2 border rounded text-sm space-y-1">
                    <div className="flex items-start gap-2">
                      {conflict.severity === 'error' ? (
                        <AlertCircle className="h-4 w-4 text-red-500 mt-0.5" />
                      ) : conflict.severity === 'warning' ? (
                        <AlertCircle className="h-4 w-4 text-yellow-500 mt-0.5" />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <div className="font-medium">
                          {conflict.severity === 'error' ? '错误' : 
                           conflict.severity === 'warning' ? '警告' : '提示'}
                          : {conflict.explanation}
                        </div>
                        {conflict.userText && (
                          <div className="text-xs text-muted-foreground mt-1">
                            用户文本: "{conflict.userText}"
                          </div>
                        )}
                        <div className="text-xs text-muted-foreground">
                          系统规则: {conflict.systemRule}
                        </div>
                        {conflict.lineNumber && (
                          <div className="text-xs text-muted-foreground">
                            位置: 第{conflict.lineNumber}行
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 建议列表 */}
            {analysisResult.suggestions.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-medium text-muted-foreground">优化建议</h4>
                {analysisResult.suggestions.map((suggestion) => (
                  <div key={suggestion.id} className="p-2 border rounded text-sm">
                    <div className="font-medium mb-1">{suggestion.title}</div>
                    <div className="text-xs text-muted-foreground">{suggestion.description}</div>
                    {suggestion.oldText && suggestion.newText && (
                      <div className="mt-1 text-xs">
                        <span className="line-through text-red-600">{suggestion.oldText}</span>
                        {' → '}
                        <span className="text-green-600">{suggestion.newText}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* 无问题时的提示 */}
            {analysisResult.conflicts.length === 0 && (
              <div className="p-4 text-center text-sm text-muted-foreground">
                <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                <p>未发现与系统规则的冲突</p>
              </div>
            )}
          </div>
        )}

        {/* 初始状态提示 */}
        {!analysisResult && !isAnalyzing && (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <Search className="h-8 w-8 mb-2" />
            <p className="text-sm">点击"检查冲突"开始分析</p>
            <p className="text-xs mt-1">系统将检查Prompt与交易规则的兼容性</p>
          </div>
        )}

        {/* 加载中状态 */}
        {isAnalyzing && (
          <div className="flex flex-col items-center justify-center h-full">
            <Loader className="h-8 w-8 animate-spin text-primary mb-2" />
            <p className="text-sm text-muted-foreground">正在分析...</p>
          </div>
        )}
      </div>
    </div>
  )
}