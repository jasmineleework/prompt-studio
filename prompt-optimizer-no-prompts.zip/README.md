# Prompt Workbench

A professional prompt engineering workbench designed for AI trading systems. Manage, version, and optimize your trading prompts with AI-powered analysis and real-time diff comparison.

## ✨ Features

### 📝 Professional Editor
- Monaco Editor integration with syntax highlighting
- Real-time editing with auto-save support
- Markdown preview and formatting

### 🔄 Version Control
- Automatic version tracking for every change
- Visual diff comparison before saving
- Version history browsing and rollback
- Export versions as Markdown files

### 🤖 AI Analysis
- Conflict detection between prompt rules
- Compatibility scoring with system constraints
- Smart suggestions for prompt optimization

### 📁 Project Management
- Multiple project support
- Local file backup (auto-save to `/prompts` folder)
- Export all data as JSON for backup
- Project import/export functionality

### ⚙️ Configuration
- System constraints management
- Output format specifications
- AI model settings (OpenAI API)

## 🛠️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **UI**: Tailwind CSS + Radix UI
- **Editor**: Monaco Editor
- **State**: Zustand
- **Storage**: IndexedDB
- **Diff**: react-diff-viewer-continued

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/prompt-workbench.git
cd prompt-workbench

# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Environment Variables

Create a `.env.local` file in the root directory:

```env
OPENAI_API_KEY=your_api_key_here
```

## 📖 Usage

### Creating a Project

1. Click the **+** button in the project panel
2. Enter a project name
3. Start writing your prompt in the editor

### Saving Versions

1. Edit your prompt content
2. Click the **Save** button
3. Review the diff comparison
4. Add a version description (optional)
5. Click **Confirm Save**

### Exporting Data

- **Single prompt**: Click the download icon in the toolbar
- **All data**: Click the export icon in the project panel header

### AI Conflict Analysis

1. Configure your AI settings in the config panel
2. Add your OpenAI API key
3. Click **Check Conflicts** to analyze your prompt

## 📁 Project Structure

```
├── app/
│   ├── api/              # API routes
│   ├── globals.css       # Global styles
│   ├── layout.tsx        # Root layout
│   └── page.tsx          # Main page
├── components/
│   ├── ai/               # AI analysis components
│   ├── config/           # Configuration panels
│   ├── editor/           # Editor and toolbar
│   ├── project/          # Project management
│   └── version/          # Version control UI
├── lib/
│   ├── stores/           # Zustand stores
│   ├── services/         # API services
│   └── utils.ts          # Utility functions
├── types/                # TypeScript types
└── prompts/              # Local prompt backups (auto-generated)
```

## 🔧 Development

```bash
# Run development server
npm run dev

# Type checking
npm run type-check

# Linting
npm run lint

# Build for production
npm run build
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📧 Contact

For questions or feedback, please open an issue on GitHub.

---

Made with ❤️ for the trading community

