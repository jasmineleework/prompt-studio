'use client'

import { useState, useEffect } from 'react'
import { ProjectPanel } from '@/components/project/ProjectPanel'
import { PromptEditor } from '@/components/editor/PromptEditor'
import { ConfigPanel } from '@/components/config/ConfigPanel'
import { AIOptimizer } from '@/components/ai/AIOptimizer'
import { useProjectStore } from '@/lib/stores/projectStore'
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react'

export default function Home() {
  const { loadProjects } = useProjectStore()
  const [isLoading, setIsLoading] = useState(true)
  const [isAIPanelCollapsed, setIsAIPanelCollapsed] = useState(() => {
    // 从 localStorage 读取折叠状态，默认为折叠
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('aiPanelCollapsed')
      return saved !== null ? saved === 'true' : true
    }
    return true
  })

  useEffect(() => {
    loadProjects().then(() => {
      setIsLoading(false)
    })
  }, [loadProjects])

  useEffect(() => {
    // 保存折叠状态到 localStorage
    localStorage.setItem('aiPanelCollapsed', String(isAIPanelCollapsed))
  }, [isAIPanelCollapsed])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading workspace...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Left Sidebar - 项目和配置 */}
      <div className="w-64 border-r border-border flex flex-col">
        <ProjectPanel />
        <ConfigPanel />
      </div>

      {/* Main Content - 编辑器 */}
      <div className="flex-1 overflow-hidden">
        <PromptEditor />
      </div>

      {/* Right Sidebar - AI分析 */}
      <div 
        className={`border-l border-border transition-all duration-300 ease-in-out ${
          isAIPanelCollapsed ? 'w-12' : 'w-96'
        }`}
      >
        {isAIPanelCollapsed ? (
          <button
            onClick={() => setIsAIPanelCollapsed(false)}
            className="h-full w-full flex flex-col items-center justify-center gap-2 hover:bg-accent/50 transition-colors"
            title="展开 AI 分析面板"
          >
            <ChevronLeft className="h-4 w-4" />
            <Sparkles className="h-4 w-4" />
          </button>
        ) : (
          <div className="h-full relative">
            <button
              onClick={() => setIsAIPanelCollapsed(true)}
              className="absolute top-4 right-2 z-10 p-1 hover:bg-accent rounded transition-colors"
              title="折叠 AI 分析面板"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <AIOptimizer />
          </div>
        )}
      </div>
    </div>
  )
}