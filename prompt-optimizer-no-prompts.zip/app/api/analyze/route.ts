import { NextRequest, NextResponse } from 'next/server'
import { aiAnalyzer } from '@/lib/services/aiAnalyzer'
import { AnalysisRequest, AnalysisResponse } from '@/types/trading'

export async function POST(request: NextRequest) {
  try {
    const body: AnalysisRequest = await request.json()
    const { prompt, config, useAI } = body
    
    if (!prompt || !config) {
      return NextResponse.json(
        { success: false, error: '缺少必要参数' },
        { status: 400 }
      )
    }
    
    // 执行AI冲突分析（优先AI，回退到规则检测）
    const analysis = await aiAnalyzer.analyzeConflicts(
      prompt,
      config.systemConstraints,
      config.outputFormat,
      config.aiConfig
    )
    
    const response: AnalysisResponse = {
      success: true,
      analysis
    }
    
    return NextResponse.json(response)
  } catch (error) {
    console.error('Analysis error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : '分析失败' 
      },
      { status: 500 }
    )
  }
}