import { NextRequest, NextResponse } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import path from 'path'

interface SaveLocalRequest {
  projectName: string
  folderName?: string  // 可选的文件夹名称
  versionNumber: number
  content: string
}

export async function POST(request: NextRequest) {
  try {
    const body: SaveLocalRequest = await request.json()
    const { projectName, folderName, versionNumber, content } = body
    
    if (!projectName || !versionNumber || content === undefined) {
      return NextResponse.json(
        { success: false, error: '缺少必要参数' },
        { status: 400 }
      )
    }
    
    // 清理项目名称和文件夹名称，移除不安全字符
    const safeProjectName = projectName.replace(/[<>:"/\\|?*]/g, '_')
    const safeFolderName = folderName ? folderName.replace(/[<>:"/\\|?*]/g, '_') : null
    
    // 项目根目录下的 prompts 文件夹
    const promptsDir = path.join(process.cwd(), 'prompts')
    
    // 如果有文件夹，创建文件夹结构
    let projectDir: string
    if (safeFolderName) {
      const folderDir = path.join(promptsDir, safeFolderName)
      projectDir = path.join(folderDir, safeProjectName)
    } else {
      projectDir = path.join(promptsDir, safeProjectName)
    }
    
    // 确保目录存在
    if (!existsSync(promptsDir)) {
      await mkdir(promptsDir, { recursive: true })
    }
    if (!existsSync(projectDir)) {
      await mkdir(projectDir, { recursive: true })
    }
    
    // 保存文件
    const fileName = `${safeProjectName}_v${versionNumber}.md`
    const filePath = path.join(projectDir, fileName)
    
    await writeFile(filePath, content, 'utf-8')
    
    // 构建返回路径
    let relativePath: string
    if (safeFolderName) {
      relativePath = `prompts/${safeFolderName}/${safeProjectName}/${fileName}`
    } else {
      relativePath = `prompts/${safeProjectName}/${fileName}`
    }
    
    return NextResponse.json({
      success: true,
      path: relativePath
    })
  } catch (error) {
    console.error('Save local error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : '保存失败' 
      },
      { status: 500 }
    )
  }
}

