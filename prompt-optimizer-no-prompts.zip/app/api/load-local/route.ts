import { NextResponse } from 'next/server'
import fs from 'fs/promises'
import path from 'path'
import { ProjectStructure } from '@/types'

interface LocalProject {
  name: string
  versions: {
    versionNumber: number
    content: string
    fileName: string
  }[]
}

export async function GET() {
  try {
    const projectsDir = path.join(process.cwd(), 'prompts')
    
    try {
      await fs.access(projectsDir)
    } catch {
      return NextResponse.json({ 
        success: true, 
        projects: [],
        structure: null,
        lastModified: null
      })
    }
    
    const items = await fs.readdir(projectsDir)
    const projects: LocalProject[] = []
    
    for (const item of items) {
      const itemPath = path.join(projectsDir, item)
      const stats = await fs.stat(itemPath)
      
      if (stats.isDirectory()) {
        // 直接将每个目录视为项目目录
        const projectVersions = await loadProjectVersions(itemPath, item)
        if (projectVersions.versions.length > 0) {
          projects.push(projectVersions)
        }
      }
    }
    
    // 读取项目结构配置
    let structure: ProjectStructure | null = null
    const structureFilePath = path.join(projectsDir, 'structure.json')
    try {
      const structureContent = await fs.readFile(structureFilePath, 'utf-8')
      structure = JSON.parse(structureContent)
    } catch (error) {
      console.log('No structure file found, will create default one')
    }
    
    // 获取 prompts 目录的最后修改时间
    let lastModified: string | null = null
    try {
      const stats = await fs.stat(projectsDir)
      lastModified = stats.mtime.toISOString()
    } catch (error) {
      console.log('Could not get directory modification time')
    }

    return NextResponse.json({ 
      success: true, 
      projects: projects,
      structure: structure,
      lastModified: lastModified
    })
  } catch (error) {
    console.error('Failed to load local projects:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to load local projects',
      projects: [],
      structure: null,
      lastModified: null
    }, { status: 500 })
  }
}

async function loadProjectVersions(projectPath: string, projectName: string): Promise<LocalProject> {
  const project: LocalProject = {
    name: projectName,
    versions: []
  }
  
  try {
    const files = await fs.readdir(projectPath)
    const mdFiles = files
      .filter(f => f.endsWith('.md'))
      .sort()
    
    for (const file of mdFiles) {
      const versionMatch = file.match(/_v(\d+)\.md$/)
      const versionNumber = versionMatch ? parseInt(versionMatch[1]) : 1
      
      const content = await fs.readFile(
        path.join(projectPath, file),
        'utf-8'
      )
      
      project.versions.push({
        versionNumber,
        content,
        fileName: file
      })
    }
    
    project.versions.sort((a, b) => a.versionNumber - b.versionNumber)
  } catch (error) {
    console.error(`Failed to load versions for ${projectName}:`, error)
  }
  
  return project
}