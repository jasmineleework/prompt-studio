import { NextResponse } from 'next/server'

export async function POST() {
  return NextResponse.json({ 
    success: true, 
    message: 'Database should be cleared on client side' 
  })
}

// 这个端点用于触发客户端清空数据库
// 实际的清理逻辑在客户端执行