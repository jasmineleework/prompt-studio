# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is an AI Trading Prompt Optimization Workbench - a specialized tool for optimizing and managing prompts used in AI-powered trading systems. The application focuses on version control, static analysis, and AI-assisted optimization of trading prompts.

## Core Architecture

### Tech Stack
- **Frontend**: Next.js 14 (App Router) + React 18 + TypeScript
- **UI Components**: shadcn/ui + Tailwind CSS + Radix UI
- **Editor**: Monaco Editor (@monaco-editor/react)
- **State Management**: Zustand
- **Storage**: IndexedDB (via idb library)
- **Version Comparison**: react-diff-viewer-continued
- **AI Integration**: OpenAI API

### Key Architectural Decisions

1. **Automatic Versioning System**: Every edit triggers auto-save with debounce (1 second), creating new version entries automatically. Version numbers increment sequentially (v1, v2, v3...).

2. **Storage Strategy**: Using IndexedDB for local persistence of projects, versions, and configurations. Each project maintains its own version history.

3. **Component Structure**:
   - `/components/editor/` - Monaco Editor wrapper with auto-save logic
   - `/components/project/` - Project management UI
   - `/components/version/` - Version control UI (history, diff, rollback)
   - `/components/config/` - Configuration panels
   - `/components/ai/` - AI analysis and optimization components

4. **State Management Pattern**: Zustand stores in `/lib/stores/` manage:
   - Current project state
   - Active version
   - Editor content
   - UI state (panels, dialogs)

## Development Commands

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Run production server
npm start

# Type checking
npm run type-check

# Linting
npm run lint
```

## Critical Implementation Notes

### Version Control Implementation
- Version saves are triggered by editor onChange events with 1-second debounce
- Each version stores: content, timestamp, version number, and metadata
- Diff comparison uses unified diff format
- Rollback creates a new version (never overwrites history)

### AI Integration Points
1. **Static Analysis** (`/api/analyze`): Validates prompt structure without execution
2. **Optimization** (`/api/optimize`): Generates improved versions using AI
3. **Version Description** (`/api/describe`): Auto-generates change summaries

### Data Models

```typescript
interface Version {
  id: string;
  versionNumber: number;
  content: string;
  timestamp: Date;
  description?: string;
  metadata: {
    lines: number;
    characters: number;
    changeType: 'minor' | 'major';
  }
}

interface Project {
  id: string;
  name: string;
  currentVersion: number;
  versions: Version[];
  config: ProjectConfig;
  createdAt: Date;
  updatedAt: Date;
}
```

## Project-Specific Features

1. **Trading Context**: Prompts are optimized specifically for trading scenarios with validations for:
   - Risk management rules
   - Trading signal clarity
   - Output format specifications

2. **No Test Execution**: This version does NOT execute prompts. All analysis is static.

3. **Configuration Panel**: Manages three key areas:
   - System capability limits
   - Output requirements
   - Test input data (static only)

## API Routes Structure

- `/api/projects` - CRUD operations for projects
- `/api/versions` - Version management endpoints
- `/api/ai/analyze` - Static prompt analysis
- `/api/ai/optimize` - AI-powered optimization
- `/api/ai/suggest` - Contextual suggestions

## UI Layout Convention

The application uses a three-panel layout:
- **Left**: Project list and configuration
- **Center**: Monaco Editor with auto-save indicator
- **Right**: Version history and controls

## Common Patterns

### Auto-save Implementation
```typescript
// Use debounced save in editor components
const debouncedSave = useMemo(
  () => debounce((content: string) => {
    saveNewVersion(content);
  }, 1000),
  []
);
```

### Version Comparison
Always use react-diff-viewer-continued for consistent diff visualization across the application.

## Environment Variables

Required environment variables in `.env.local`:
```
OPENAI_API_KEY=your_api_key_here
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Known Constraints

1. All data is stored locally in browser (IndexedDB)
2. No backend database - export/import for backup
3. Version history limited to 100 versions per project (configurable)
4. AI features require OpenAI API key